export function doit () {
	alert('hi');
}