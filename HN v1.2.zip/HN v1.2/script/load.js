let img;

function ImportFeatureGroup(identity, source) {
  fetch(source).then(resp => {
    return resp.json();
  }).then(data => {
    for (const [key, value] of Object.entries(data)) {
      img = document.createElement("img")
      img.src = value;
      img.id = key;

      document.getElementById(identity).appendChild(img);
    }
  });
}

ImportFeatureGroup("creatures", "./feature_pack/creature/creature.json");
ImportFeatureGroup("items", "./feature_pack/item/item.json");
ImportFeatureGroup("uis", "./feature_pack/ui/ui.json");
