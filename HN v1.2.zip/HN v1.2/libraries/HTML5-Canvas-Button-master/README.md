#HTML5Button
===========
A JavaScript Library to for Creating HTML5 Buttons. Please look open **index.html**  and **main.js** to view a working sample.
