//Math tools
function R2D(radian) {
	return radian * 180 / Math.PI;
}
function D2R(degree) {
	return degree * Math.PI / 180;
}

function Id2Name(iden, isItemNotBlock) {
	if (isItemNotBlock) {
		switch (iden) {
			case 0: return "empty"; break;
			case 1: return "apple"; break;
			case 2: return "bear_trap_closed"; break;
			case 3: return "bear_trap_opened"; break;
		}
	} else {
		switch (iden) {
			case 0: return "void"; break;
			case 1: return "grass"; break;
			case 2: return "sand"; break;
			case 3: return "water"; break;
			case 4: return "lava"; break;
		}
	}
}
function Name2Id(name, isItemNotBlock) {
	if (isItemNotBlock) {
		switch (name) {
			case "empty": return 0; break;
			case "apple": return 1; break;
			case "bear_trap_closed": return 2; break;
			case "bear_trap_opened": return 3; break;
		}
	} else {
		switch (name) {
			case "void": return 0; break;
			case "grass": return 1; break;
			case "sand": return 2; break;
			case "water": return 3; break;
			case "lava": return 4; break;
		}
	}
}

//declarations
let canvas = document.getElementById("cv");
let x_blocks = Math.floor(window.innerWidth * 0.99 / 80);
canvas.width = x_blocks * 80;
let y_blocks = Math.floor(window.innerHeight / 80);
canvas.height = y_blocks * 80;
let block_side = 80;
let c = canvas.getContext("2d");

let Default_Map, Default_Player, Villains;
let updating, fps = 25, playerScore, survivalTime, timeSlot;
let cur = new Image(), keys = [], mous = {
	"distance_to": target => {
		return Math.sqrt((mous["x_coord"] - target.x_coord) ** 2 + (mous["y_coord"] - target.y_coord) ** 2);
	},

	"angle_to": target => {
		let a = R2D(Math.atan((mous["y_coord"] - target.y_coord) / (mous["x_coord"] - target.x_coord)));

		if (mous["y_coord"] > target.y_coord && mous["x_coord"] > target.x_coord) {
			null;
		} else if (mous["x_coord"] < target.x_coord) {
			a += 180;
		} else if (mous["y_coord"] < target.y_coord && mous["x_coord"] > target.x_coord) {
			a += 360;
		} else if (mous["x_coord"] >= target.x_coord && mous["y_coord"] == target.y_coord) {
			a = 0;
		} else if (mous["x_coord"] == target.x_coord && mous["y_coord"] > target.y_coord) {
			a = 90;
		} else if (mous["x_coord"] == target.x_coord && mous["y_coord"] < target.y_coord) {
			a = 270;
		}

		return a;
	}
};

//Classes
class item {
	constructor(iden) {
		this.iden = iden;
	}
}
class block {
	constructor(iden, hv_item) {
		this.iden = iden;
		this.hv_item = hv_item;

		Default_Map.block_num[iden]++;

		this.probit = 0;
	}

	get friction() {
		switch (this.iden) {
			case 0: return 1; break;
			case 1: return 0.9; break;
			case 2: return 0.9; break;
			case 3: return 0.25; break;
			case 4: return 0.25; break;
		}
	}

	get block_colour() {
		switch (this.iden) {
			case 0: return "rgb(0, 0, 0, 0)"; break;
			case 1: return "#33BB33"; break;
			case 2: return "#FFFFAA"; break;
			case 3: return "rgba(0, 0, 255, 0.75)"; break;
			case 4: return "#FF4411"; break;
		}
	}
}
class map {
	constructor(x, y, mode/*0:god;1:mortal*/, difficulty /*0:peaceful;1:easy;2:normal;3:hard*/, type /*0:Messy;1:Island*/) {
		this.x = x;
		this.y = y;
		this.mode = parseInt(mode);
		this.difficulty = parseInt(difficulty);
		this.type = parseInt(type);

		this.map_data = [];
		this.block_num = [];
		for (let num = 0; num < 5; num++) {
			this.block_num[num] = 0;
		}

		for (let n = 0; n < x_blocks; n++) {
			this.map_data.push([]);
		}
	}

	corr_block(obj) {
		return {y: Math.floor(obj.y_coord / block_side), x: Math.floor(obj.x_coord / block_side)};
	}
	within_block(obj) {
		//use promise
		//return {y: Math.floor(obj.y_coord / block_side), x: Math.floor(obj.x_coord / block_side)};
	}
	highlight_block() {
		c.lineWidth = 2;
		c.strokeStyle = "black";
		c.strokeRect(block_side * this.corr_block(mous)["x"], block_side * this.corr_block(mous)["y"], block_side, block_side);
	}

	fill_map(startX, startY, endX, endY, blk) {
		for (let i = startX; i < endX; i++) {
			for (let j = startY; j < endY; j++) {
				this.map_data[j][i] = new block(blk, 0);
			}
		}
	}
	gen_map(type) {
		switch (type) {
			case 0: {
				for (let i = 0; i < this.x; i++) {
					for (let j = 0; j < this.y; j++) {
						let rnd = Math.floor(Math.random()*3 + 1);
						this.map_data[j][i] = new block(rnd, 0);
					}
				}

				break;
			}
			case 1: {
				let startPoint = {y: Math.floor(this.y / 2), x:Math.floor(this.x / 2)};
				this.fill_map(0, 0, this.x, this.y, 3);

				/*let rnd = Math.floor(Math.random()*2 + 1);
				this.map_data[startPoint.y][startPoint.x] = new block(rnd, 0);*/

				let randomMaxSizeProbit = 0.5 + Math.random() / 2;
				for (let i = 0; i < this.x; i++) {
					for (let j = 0; j < this.y; j++) {
						this.map_data[j][i].probit = Math.sqrt((Math.sin(D2R(i * 180 / this.x)) ** 2 + Math.sin(D2R(j * 180 / this.y)) ** 2) / 2);
						if (this.map_data[j][i].probit * Math.sqrt(Math.random()) > 0.8) {
							this.map_data[j][i] = new block(Math.floor(Math.random() * 2) + 1, 0);
						} else if (this.map_data[j][i].probit > randomMaxSizeProbit) {
							this.map_data[j][i] = new block(Math.floor(Math.random() * 2) + 1, 0);
						}
					}
				}

				/*decideNextX(Math.floor(Math.random()*3 - 1), Math.floor(this.x * ));
				function decideNextX(dir, lim) {
					if (dir == 0) {
						decideNextY(Math.floor(Math.random()*3 - 1));
						break;
					}
					let r = Math.floor(Math.random()*3 + 1)
				}
				function decideNextY(dir, lim) {
					if (dir == 0) {
						decideNextX(Math.floor(Math.random()*3 - 1));
						break;
					}
				}*/
				break;
			}
			case 2: {
				this.fill_map(0, 0, this.x, this.y, 4);
				this.fill_map(Math.round(this.x / 6), Math.round(this.y / 6), Math.round(this.x * 5 / 6), Math.round(this.y * 5 / 6), Math.floor(Math.random() * 2) + 1);

				break;
			}
		}
	}
	update_map() {
		switch (this.type) {
			case 2: {
				if (survivalTime % 1000 == 0) {
					let rndX = Math.floor(Math.random()*this.x), rndY = Math.floor(Math.random()*this.y);
					this.map_data[rndY][rndX] = new block(4, 0);
				}
			}
		}
	}
	print_map() {
		for (let i = 0; i < this.x; i++) {
			for (let j = 0; j < this.y; j++) {
				c.fillStyle = this.map_data[j][i].block_colour;
				c.fillRect(block_side * i, block_side * j, block_side, block_side);
			}
		}
		this.highlight_block();
	}

	gen_apple(apple_num) {
		let apple_count = 0, i, j;
		do {
			i = Math.floor(Math.random() * x_blocks);
			j = Math.floor(Math.random() * y_blocks);
			if (this.map_data[j][i].hv_item == 0 && this.map_data[j][i].iden == 1) {
				this.map_data[j][i].hv_item = 1;
				apple_count++;
			}
		} while (apple_count < apple_num && apple_count < this.block_num[1]);
	}

	spawn_item() {
		for (let i = 0; i < x_blocks; i++) {
			for (let j = 0; j < y_blocks; j++) {
				if (this.map_data[j][i].hv_item != 0) c.drawImage(document.getElementById(Id2Name(this.map_data[j][i].hv_item, true)), block_side * (i + 0.5) - document.getElementById(Id2Name(this.map_data[j][i].hv_item, true)).width / 2, block_side * (j + 0.5) - document.getElementById(Id2Name(this.map_data[j][i].hv_item, true)).height / 2);
			}
		}
	}
}
class creature {
	constructor(name, x_coord, y_coord) {
		this.name = name;
		this.x_coord = x_coord;
		this.y_coord = y_coord;

		this.timeSlot = {
			"burn_inst": -500
		};

		this.x_vel = 0;
		this.y_vel = 0;
		this.health = 100;

		this.isJumping = false;
		this.isBurning = false;
		this.isSprinting = false;
		this.isDiagMoving = false;
		this.isMovable = true;
	}

	attack(target) {
		target.health -= this.damage;
		target.x_vel = target.y_vel *= -this.damage / 10;
	}
	burn() {
		this.isBurning = Default_Map.map_data[Default_Map.corr_block(this).y][Default_Map.corr_block(this).x].iden == 4;

		if (this.isBurning && survivalTime - this.timeSlot["burn_inst"] > 500) {
			this.health -= 5;

			this.timeSlot["burn_inst"] = survivalTime;
		}
	}

	gen_creature() {
		c.fillStyle = "black";
		c.font = "bold 20px Arial";
		c.textAlign = "center";

		if (this.isBurning && survivalTime - this.timeSlot["burn_inst"] > 500) c.filter = "saturate(5)";
		c.drawImage(this.img, this.x_coord - this.img.width / 2, this.y_coord - this.img.height / 2);
		c.filter = "none";

		c.strokeStyle = 'black';
		c.fillStyle = 'white';
		c.lineWidth = 6;
		c.strokeText(this.name, this.x_coord, this.y_coord - block_side / 2);
		c.strokeText(`HP: ${this.health}%`, this.x_coord, this.y_coord + block_side * 0.75);
		c.fillText(this.name, this.x_coord, this.y_coord - block_side / 2);
		if (this.health > 20 && this.health <= 60) {
            c.fillStyle = "#FFCC00";
        } else if (this.health > 0 && this.health <= 20) {
            c.fillStyle = "red";
        } else {
			c.fillStyle = "white";
        }
		c.fillText(`HP: ${this.health}%`, this.x_coord, this.y_coord + block_side * 0.75);
	}

	move_creature() {
		//set speed and displacement
		this.x_vel *= this.isSprinting ? 0.95 : 0.9;
		this.x_coord += this.x_vel;// * (this.isDiagMoving ? 0.5 : 1);
		this.y_vel *= this.isSprinting ? 0.95 : 0.9;
		this.y_coord += this.y_vel;// * (this.isDiagMoving ? 0.5 : 1);

		//set boundaries
		if (this.x_coord >= canvas.width) {
      this.x_coord = canvas.width - 1; //-1 is to prevent bug
    } else if (this.x_coord <= 0) {
      this.x_coord = 0;
    }
    if (this.y_coord >= canvas.height) {
      this.y_coord = canvas.height - 1; //-1 is to prevent bug
    } else if (this.y_coord <= 0) {
      this.y_coord = 0;
    }
	}

	onItem(blk, acc_lst) {
		if (acc_lst.indexOf(blk.hv_item) != -1) {
			switch (blk.hv_item) {
				case 0: null; break;
				case 1: {
					playerScore += 1;
					this.health += 10;
					if (Default_Map.mode != 0 && this.health > 100) {
						this.health = 100;
					}
					blk.hv_item = 0;
					Default_Map.gen_apple(1);
					break;
				}
				case 2: {
					break;
				}
				case 3: {
					this.health -= 50;
					this.isMovable = false;
					blk.hv_item = 2;

					break;
				}
			}
		}
	}

	distance_to(target) {
		return Math.sqrt((this.x_coord - target.x_coord) ** 2 + (this.y_coord - target.y_coord) ** 2);
	}

	angle_to(target) {
		let angle = R2D(Math.atan((this.y_coord - target.y_coord) / (this.x_coord - target.x_coord)));

		if (this.y_coord > target.y_coord && this.x_coord > target.x_coord) null;
		else if (this.x_coord < target.x_coord) angle += 180;
		else if (this.y_coord < target.y_coord && this.x_coord > target.x_coord) angle += 360;
		else if (this.x_coord >= target.x_coord && this.y_coord == target.y_coord) angle = 0;
		else if (this.x_coord == target.x_coord && this.y_coord > target.y_coord) angle = 90;
		else if (this.x_coord == target.x_coord && this.y_coord < target.y_coord) angle = 270;

		return angle;
	}
}
class player extends creature {
	constructor(name, x_coord, y_coord) {
		super(name, x_coord, y_coord);
		this.img = document.getElementById("player");
		this.isDead = false;
		this.health = Default_Map.mode == 0 ? Infinity : 100;

		this.max_speed = 15;

		this.item_list = [0, 1, 2, 3];
		this.item_held = 0;
		this.put_item_speed = 5;

		this.block_held = 0;
		this.put_block_speed = 2;

		this.isAttacking = false;
		this.attack_speed = 3;
		this.damage = 20;
		this.attack_range = 160;
		this.attack_angle = 50;
	}

	showHolding(item) {
		c.save();
		c.translate(this.x_coord, this.y_coord);
		c.rotate(D2R(mous.angle_to(this)));
		if (item != 0) {
			c.shadowBlur = 5;
			c.shadowColor = "white";
			c.drawImage(document.getElementById(Id2Name(item, true)), this.img.width, -document.getElementById(Id2Name(item, true)).height / 2);
		}
		c.restore();
	}
	showAttack(max_width, colour, offset, sA, eA, dA) {
		c.lineWidth = max_width * Math.sin(D2R((survivalTime - timeSlot["attack_ani"]) * 180 / (1000 / Default_Player.attack_speed)));
		c.strokeStyle = colour;
		c.beginPath();
		c.arc(this.x_coord, this.y_coord, this.attack_range * 0.7, sA + dA * offset + dA * (survivalTime - timeSlot["attack_ani"]) / Math.round(1000 / fps), sA + dA * (offset + 1) + dA * (survivalTime - timeSlot["attack_ani"]) / Math.round(1000 / fps));
		c.stroke();
	}

	put_block(blk) {
		Default_Map.map_data[Default_Map.corr_block(mous)["y"]][Default_Map.corr_block(mous)["x"]] = new block(blk, 0);
	}
	put_item(itm) {
		if (Default_Map.map_data[Default_Map.corr_block(mous)["y"]][Default_Map.corr_block(mous)["x"]].hv_item == 0) Default_Map.map_data[Default_Map.corr_block(mous)["y"]][Default_Map.corr_block(mous)["x"]].hv_item = itm;
	}

	destroy_item() {
		Default_Map.map_data[Default_Map.corr_block(mous)["y"]][Default_Map.corr_block(mous)["x"]].hv_item = 0;
	}

	handle_item() {
		switch (Default_Map.map_data[Default_Map.corr_block(mous)["y"]][Default_Map.corr_block(mous)["x"]].hv_item) {
			case 2: {
				Default_Map.map_data[Default_Map.corr_block(mous)["y"]][Default_Map.corr_block(mous)["x"]].hv_item = 3;
				break;
			}
		}
	}

	jump() {
		//timeSlot["jump_inst"] = survivalTime;this.isJumping = survivalTime - timeSlot["attack_inst"] >= 1000 / Default_Player.attack_speed;

		this.isMovable = true;
	}
}
class villain extends creature {
	constructor(name, x_coord, y_coord) {
		super(name, x_coord, y_coord);
		this.img = document.getElementById("villain");

		this.spawn_time = survivalTime;
		this.isSpecial = false; //despawn randomly?

		this.max_speed = Default_Map.difficulty * 1.1;
		this.sight = Default_Map.difficulty * 150;
		this.damage = Default_Map.difficulty * 10;
		this.attack_range = Default_Map.difficulty * 25;
	}

	approach_to(target) {
		if (target.x_coord < this.x_coord) {
			set_move(this, "left");
		} else if (target.x_coord > this.x_coord) {
			set_move(this, "right");
		}
		if (target.y_coord < this.y_coord) {
			set_move(this, "up");
		} else if (target.y_coord > this.y_coord) {
			set_move(this, "down");
		}
	}
}

//UI and control
window.onload = function () {
	displayTutorial();
}
function validation() {
	if (document.getElementById("Name").value.trim().length > 0 && document.getElementById("Name").value.trim().length < 17) {
		init();
	} else {
		alert("Your player name must be of length between 1 to 16.");
	}
}
function BGM_switch() {
	document.getElementById("bgm").muted = !document.getElementById("bgm").muted;
	if (document.getElementById("bgm").muted) {
		document.getElementById("bgm").pause();
	} else {
		document.getElementById("bgm").play();
	}
}
function init() {
	canvas.style.cursor = "none";

	playerScore = 0;
	survivalTime = 0;
	timeSlot = {
		"attack_inst": -1000,
		"put_block_inst": -1000,
		"put_item_inst": -1000,
		"jump_inst": -1000,

		"attack_ani": 0
	};

	c.clearRect(0, 0, canvas.width, canvas.height);
	Default_Map = new map(x_blocks, y_blocks, document.getElementById("Mode").value, document.getElementById("Difficulty").value, document.getElementById("Type").value);
	Default_Player = new player(document.getElementById("Name").value.trim(), canvas.width / 2, canvas.height / 2)

	Villains = [];

	Default_Map.gen_map(Default_Map.type);
	Default_Map.print_map();
	Default_Player.gen_creature();
	Default_Map.gen_apple(4);
	Default_Map.spawn_item();

	update();
}
function capture() {
 	window.open(canvas.toDataURL(),"image from canvas");
}

//display screens
function displayBG(opacity) {
	c.fillStyle = `rgba(0, 0, 0, ${opacity})`;
	c.fillRect(0, 0, canvas.width, canvas.height);
}
function displayTutorial() {
	displayBG(1);

	c.font = "bold 28px 'Microsoft JhengHei'";
	c.fillStyle = "white";
	c.textAlign = "center";
	c.fillText("Welcome to Happy Nature!", canvas.width / 2, canvas.height / 2 - 60);
	c.fillText("操作說明(內容你自己摸索)：", canvas.width / 2, canvas.height / 2 - 32);
	c.fillText("WSAD=前後左右 | shift=加速 | space=甩trap", canvas.width / 2, canvas.height / 2);
	c.fillText("左制=打怪/item | 轆=換item | 右制=放/控制item", canvas.width / 2, canvas.height / 2 + 32);
	c.fillText("Break a leg!", canvas.width / 2, canvas.height / 2 + 60);
}
function displayDeath() {
	displayBG(0.5);
	canvas.style.cursor = "default";

	c.font = "bold 28px 'Microsoft JhengHei'";
	c.fillStyle = "white";
	c.textAlign = "center";
	c.fillText(`Game over, ${Default_Player.name}!`, canvas.width / 2, canvas.height / 2 - 32);
	c.fillText(`Your score is ${playerScore}`, canvas.width / 2, canvas.height / 2);
	c.fillText(`Your survival time is ${survivalTime / 1000} seconds`, canvas.width / 2, canvas.height / 2 + 32);
}

//Events
/*window.onbeforeunload = function() {
    return true;
};*/
document.onselectstart = function () {
	return false;
};
document.body.onkeydown = e => {
	//console.log(e.keyCode);
  keys[e.keyCode] = true;
	//e.preventDefault();
};
document.body.onkeyup = e => {
  keys[e.keyCode] = false;
};
canvas.onmousemove = e => {
	mous["x_coord"] = e.offsetX;
	mous["y_coord"] = e.offsetY;
};
canvas.onmousedown = e => {
	mous[e.button] = true;
	if (e.button == 1) return false;
};
canvas.onmouseup = e => {
	mous[e.button] = false;
};
canvas.onwheel = e => {
	e.preventDefault();

	try {
		Default_Player.item_held = (Default_Player.item_held + (e.deltaY > 0 ? 1 : -1) + Default_Player.item_list.length) % Default_Player.item_list.length;
	} catch (err) {}

};
canvas.oncontextmenu = e => {
	e.preventDefault();
};

//main procedures
function update(/*timeStamp*/) {
	//survivalTime = timeStamp;
	clearTimeout(updating);
	//window.cancelAnimationFrame(update);

	checkKey();

	c.clearRect(0, 0, canvas.width, canvas.height);
	Default_Map.update_map();
	Default_Map.print_map();
	Default_Map.spawn_item();
	Default_Player.move_creature();
	Default_Player.gen_creature();

	CheckVillainList();
	HandleVillainList();
	HandlePlayer();

	checkMou();

	document.getElementById("Score").value = playerScore;
	document.getElementById("Time").value = survivalTime / 1000;
	survivalTime += Math.round(1000 / fps);
  if (Default_Player.isDead) {
		displayDeath();
	} else {
		updating = setTimeout(update, Math.round(1000 / fps));
	}
	//updating = window.requestAnimationFrame(update);
}
function CheckVillainList() {
	if (survivalTime % (1000 * (Math.floor(Math.random() * 10) + 1)) == 0 && survivalTime != 0 && Default_Map.difficulty != 0) {
		let n = 0, l = Villains.length;
		while (n <= l) {
			if (Villains[n] == undefined) {
				Villains[n] = new villain("Villain", Math.floor(Math.random() * canvas.width), Math.floor(Math.random() * canvas.height));
				break;
			}
			n++;
		}
	}
}
function HandleVillainList() {
	for (let n = 0, l = Villains.length; n <= l; n++) {
		if (Villains[n] != undefined) {
			Villains[n].move_creature();
			Villains[n].gen_creature();
			Villains[n].burn();

			if (Villains[n].distance_to(Default_Player) <= Villains[n].sight) {
				Villains[n].approach_to(Default_Player);
				if (Villains[n].distance_to(Default_Player) <= Villains[n].attack_range && survivalTime % 1000 == 0) Villains[n].attack(Default_Player);
			}

			Villains[n].onItem(Default_Map.map_data[Default_Map.corr_block(Villains[n]).y][Default_Map.corr_block(Villains[n]).x], [3]);

			if (Villains[n].health <= 0 || survivalTime - Villains[n].spawn_time > 60000) {
				delete Villains[n];
				if (Default_Player.isAttacking) playerScore += 3;
			}
		}
	}
}
function HandlePlayer() {
	if (Default_Player.health <= 0) Default_Player.isDead = true;

	Default_Player.showHolding(Default_Player.item_list[Default_Player.item_held]);
	Default_Player.onItem(Default_Map.map_data[Default_Map.corr_block(Default_Player).y][Default_Map.corr_block(Default_Player).x], [1, 3]);

	if (Default_Player.isAttacking) {
		let startAngle = D2R(mous.angle_to(Default_Player) - Default_Player.attack_angle / 2), endAngle = D2R(mous.angle_to(Default_Player) + Default_Player.attack_angle / 2), dAngle = D2R(Default_Player.attack_angle / fps * Default_Player.attack_speed);
		if (survivalTime - timeSlot["attack_ani"] < 1000 / Default_Player.attack_speed) {
			Default_Player.showAttack(10, `rgba(64, 64, 0, 0.5)`, -2, startAngle, endAngle, dAngle);
			Default_Player.showAttack(12, `rgba(96, 96, 0, 0.75)`, -1, startAngle, endAngle, dAngle);
			Default_Player.showAttack(14, `rgba(128, 128, 0, 1)`, 0, startAngle, endAngle, dAngle);
			Default_Player.showAttack(12, `rgba(96, 96, 0, 0.75)`, 1, startAngle, endAngle, dAngle);
			Default_Player.showAttack(10, `rgba(64, 64, 0, 0.5)`, 2, startAngle, endAngle, dAngle);
		} else {
			Default_Player.isAttacking = false;
		}
	}

	Default_Player.burn();
}

function checkKey() { //13:enter;16:shift;32:space;87:W;83:S;65:A;68:D;
	Default_Player.isSprinting = keys[16];
	Default_Player.isDiagMoving = ((keys[87] && keys[65]) || (keys[87] && keys[68]) || (keys[83] && keys[65]) || (keys[83] && keys[68]));

	if (keys[87]) set_move(Default_Player, "up");
	if (keys[83]) set_move(Default_Player, "down");
	if (keys[65]) set_move(Default_Player, "left");
	if (keys[68]) set_move(Default_Player, "right");

	if (keys[32]) Default_Player.jump();
}
function checkMou() {
	cur.src = "./feature_pack/ui/cross_scope.png";
	c.drawImage(cur, mous["x_coord"] - cur.width / 2, mous["y_coord"] - cur.height / 2);

	if (mous[0]) {
		if (survivalTime - timeSlot["attack_inst"] >= 1000 / Default_Player.attack_speed) {
			if (mous["distance_to"](Default_Player) <= Default_Player.attack_range) {
				Default_Player.isAttacking = true;
				timeSlot["attack_ani"] = survivalTime;
			} else {
				//Default_Player.isDestroying = true;
				Default_Player.destroy_item();
			}

			for (let vln of Villains) {
				if (vln != undefined && mous["distance_to"](Default_Player) <= Default_Player.attack_range && vln.distance_to(Default_Player) <= Default_Player.attack_range &&
				  	Default_Player.angle_to(mous) >= Default_Player.angle_to(vln) - Default_Player.attack_angle / 2 && Default_Player.angle_to(mous) <= Default_Player.angle_to(vln) + Default_Player.attack_angle / 2) {
					Default_Player.attack(vln);
				}
			}

			timeSlot["attack_inst"] = survivalTime;
		}
	}
	if (mous[2]) {
		if (survivalTime - timeSlot["put_item_inst"] >= 1000 / Default_Player.put_item_speed) {
			if (Default_Map.map_data[Default_Map.corr_block(mous).y][Default_Map.corr_block(mous).x].hv_item != 0) {
				Default_Player.handle_item();
			} else {
				Default_Player.put_item(Default_Player.item_list[Default_Player.item_held]);
			}

			timeSlot["put_item_inst"] = survivalTime;
		}
		/*if (survivalTime - timeSlot["put_block_inst"] >= 1000 / Default_Player.put_block_speed) {
			Default_Player.put_block(4);

			timeSlot["put_block_inst"] = survivalTime;
		}*/
	}
}
function set_move(creature, control) {
	if (creature.isMovable) {
		switch (control) {
			case "up":
				if (creature.y_vel > -creature.max_speed * Default_Map.map_data[Default_Map.corr_block(creature).y][Default_Map.corr_block(creature).x].friction) creature.y_vel--; break;
			case "down":
				if (creature.y_vel < creature.max_speed * Default_Map.map_data[Default_Map.corr_block(creature).y][Default_Map.corr_block(creature).x].friction) creature.y_vel++; break;
			case "left":
				if (creature.x_vel > -creature.max_speed * Default_Map.map_data[Default_Map.corr_block(creature).y][Default_Map.corr_block(creature).x].friction) creature.x_vel--;	break;
			case "right":
				if (creature.x_vel < creature.max_speed * Default_Map.map_data[Default_Map.corr_block(creature).y][Default_Map.corr_block(creature).x].friction) creature.x_vel++; break;
		}
	} else {
		creature.x_vel = creature.y_vel = 0;

		if (Default_Map.map_data[Default_Map.corr_block(creature).y][Default_Map.corr_block(creature).x].hv_item != 2) creature.isMovable = true;
	}
}
