import {doit} from './user.js';

doit();
alert("hi");